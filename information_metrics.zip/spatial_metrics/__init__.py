{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": None,
   "id": "3f567dbd-4471-4da9-9650-f28309e12d2b",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "name": ""
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}

# from .cell_model_base import cell_model_base
# from .spatial_metrics_base import spatial_metrics_base